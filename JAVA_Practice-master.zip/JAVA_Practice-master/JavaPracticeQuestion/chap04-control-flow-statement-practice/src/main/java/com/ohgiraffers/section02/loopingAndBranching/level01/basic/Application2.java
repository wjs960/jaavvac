package com.ohgiraffers.section02.loopingAndBranching.level01.basic;

public class Application2 {

    public static void main(String[] args) {


        for (int i = 10; i > 0; i--){
            System.out.print(i + "\t");
        }
        /* 10부터 1까지 결과를 출력하세요
         *
         * -- 출력 예시 --
         * 10 9 8 7 6 5 4 3 2 1
         * */

    }

}
